<?php

namespace App\Models\Frontend;

use Illuminate\Database\Eloquent\Model;

class BooksModel extends Model
{
    //
    protected $table = 'books';
}
